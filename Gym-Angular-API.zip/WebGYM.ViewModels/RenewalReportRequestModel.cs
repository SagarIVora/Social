﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebGYM.ViewModels
{
    public class RenewalReportRequestModel
    {
        public string Paymentfromdate { get; set; }
        public string Paymentfromto { get; set; }
    }
}
